package com.springmvctest.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.springmvctest.model.User;

@Controller
public class UserController {
	
	private static Map<String,User> map = new HashMap<String,User>();
	static{
		for(int i=1;i<3;i++){
			User user = new User("zhangsan"+i, (int) (Math.random()*50));
			map.put("zhangsan"+i,user);
		}
	}
	
	//返回ModelAndView例子 http://localhost:8080/springmvctest/test.shtml
	@RequestMapping("test")
	public Object getTest(){
		User user = new User("zhangsan", (int) (Math.random()*50));
		ModelAndView mav = new ModelAndView();
		mav.setViewName("test");
		mav.addObject(user);
		return mav;
	}
	
	//返回字符串处理例子 http://localhost:8080/springmvctest/helloworld.shtml
	@RequestMapping("helloworld")
	@ResponseBody
	public Object helloworld(){
		return "helloworld";
	}
	
	//实体bean转json http://localhost:8080/springmvctest/getUser.shtml
	@RequestMapping("getUser")
	@ResponseBody
	public Object getUser(){
		User user = new User("zhangsan", (int) (Math.random()*50));
		return user;
	}
	
	//数组转json http://localhost:8080/springmvctest/getUsers.shtml
	@RequestMapping("getUsers")
	@ResponseBody
	public Object getUsers(){
		return map.values().toArray();
	}
	
	//Collection集合转json http://localhost:8080/springmvctest/getUserCollection.shtml
	@RequestMapping("getUserCollection")
	@ResponseBody
	public Object getUserCollection(){
		return map.values();
	}
	
	//Map集合转json http://localhost:8080/springmvctest/getUserMap.shtml
	@RequestMapping("getUserMap")
	@ResponseBody
	public Object getUserMap(){
		return map;
	}
	
	//PathVariable注解例子 http://localhost:8080/springmvctest/get/zhangsan1.shtml
	@RequestMapping("get/{username}")
	@ResponseBody
	public Object get(@PathVariable String username){
		User user = map.get(username);
		return user;
	}
	
	//PathVariable注解使用正则表达式 http://localhost:8080/springmvctest/get1/zhangsan1.shtml
	@RequestMapping("get1/{username:[a-z]+[1]}")
	@ResponseBody
	public Object get1(@PathVariable String username){
		User user = map.get(username);
		return user;
	}
	
	//RequestParam注解 http://localhost:8080/springmvctest/getByusername.shtml?username=zhangsan1
	@RequestMapping("getByusername")
	@ResponseBody
	public Object getByusername(@RequestParam String username){
		User user = map.get(username);
		return user;
	}
	
	//RequestBody注解 http://localhost:8080/springmvctest/getRequestBody.shtml 请求体内容：test
	@RequestMapping("getRequestBody")
	@ResponseBody
	public Object getRequestBody(@RequestBody String requestBody){
		
		return "testRequestBody:"+requestBody;
	}
	
	//ModelAttribute注解 http://localhost:8080/springmvctest/getUserByUser.shtml?name=lisi&age=32
	@RequestMapping(value="getUserByUser")
	@ResponseBody
	public Object getUserByUser(@ModelAttribute("user") User user){
		
		return user;
	}
	
	//请求、响应作为方法参数 http://localhost:8080/springmvctest/getUserByRequest.shtml?name=wangwu&age=32
	@RequestMapping(value="getUserByRequest")
	@ResponseBody
	public Object getUserByRequest(HttpServletRequest request , HttpServletResponse response){
		String name = request.getParameter("name");
		int age = Integer.parseInt(request.getParameter("age"));
		return new User(name , age);
	}
	
	//上传文件 http://localhost:8080/springmvctest/upload.shtml
	@RequestMapping(value="upload")
	@ResponseBody
	public Object upload(@RequestParam("files") MultipartFile[] files){
		StringBuffer sb = new StringBuffer();
		for(MultipartFile file : files){
			int size = (int) (file.getSize()/1024);
			sb.append("upload success,this file size is "+size+"KB.<br/>");
		}
		return sb.toString();
	}
	

	//ExceptionHandler注解例子 http://localhost:8080/springmvctest/exceptiontest.shtml
	@RequestMapping("exceptiontest")
	public void exceptiontest(){
		String str = null;
//		Integer.parseInt(str);//报NumberFormatException异常
		str.trim();//报NullPointerException异常
	}
	
	@ResponseBody
	@ExceptionHandler(value={NullPointerException.class,NumberFormatException.class})
	public Object exception(Exception e){
		return "it is error page:" + e.getMessage();
	}
	
	//异常统一处理例子 http://localhost:8080/springmvctest/exceptiontest1.shtml
	@RequestMapping("exceptiontest1")
	public void exceptiontest1(){
		int i = 1/0;
	}
}
