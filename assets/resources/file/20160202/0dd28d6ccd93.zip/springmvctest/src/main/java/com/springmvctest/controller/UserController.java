package com.springmvctest.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.springmvctest.model.User;

@Controller
public class UserController {
	
	//返回ModelAndView例子 http://localhost:8080/springmvctest/test.shtml
	@RequestMapping("test")
	public Object getTest(){
		User user = new User("zhangsan", (int) (Math.random()*50));
		ModelAndView mav = new ModelAndView();
		mav.setViewName("test");
		mav.addObject(user);
		return mav;
	}
	
}
