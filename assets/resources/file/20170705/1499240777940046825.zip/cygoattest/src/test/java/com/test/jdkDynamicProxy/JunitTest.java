package com.test.jdkDynamicProxy;

import java.lang.reflect.Proxy;

import org.junit.Test;

public class JunitTest {

	/**
	 * 测试jdk动态代理
	 */
	@Test
	public void testJdkProxy(){
		Action obj = (Action) Proxy.newProxyInstance(ActionImp.class.getClassLoader(), ActionImp.class.getInterfaces(), new HandlerImp(new ActionImp()));
		obj.action();
	}

}
