package com.test.springevent;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationEvent;

public class Xinwen implements ApplicationContextAware{

	private ApplicationContext applicationContext;
	private String content;
	
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext = applicationContext;
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}
	
	public void process(){
		content = "新闻：小米销售额在国内第一";
		applicationContext.publishEvent(new XinwenApplicationEvent(content));
	}
	

	
	
}
