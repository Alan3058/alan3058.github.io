package com.test.springaop;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class JunitTest {

	/**
	 * 测试Spring Aop
	 */
	@Test
	public void testSpringAop(){
		ApplicationContext ctx = new ClassPathXmlApplicationContext("bean.xml");
		Manager manager = (Manager) ctx.getBean("manager");
		System.out.println("------------------------测试插入方法---------------------------");
		manager.insert("insert into sp_user(1,2,'1111')");
		System.out.println("------------------------测试查询所有数据的查询方法---------------------------");
		manager.findAll();
		System.out.println("------------------------测试查询方法---------------------------");
		manager.find("select * from sp_user");
	}

}
