package com.test.springaop;

public interface Manager {

	public abstract void insert(String sql);
	public abstract void find(String sql);
	public abstract void findAll();

}