package com.test.designermodel.observermodel;

public interface Subject {

	void execute();
	void addListener(Listener l);
	void removeListener(Listener l);
	void removeAllListener();
}
