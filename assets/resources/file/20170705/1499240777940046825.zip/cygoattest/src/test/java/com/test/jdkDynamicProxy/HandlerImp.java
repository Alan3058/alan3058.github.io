package com.test.jdkDynamicProxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;


public class HandlerImp implements InvocationHandler {
	private Object action;
	
	public HandlerImp(Action action){
		this.action = action;
	}

	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		System.out.println("-------------记录开始日志-----------------");
		Object obj = method.invoke(this.action, args);
		System.out.println("-------------记录成功日志-----------------");
		return obj;
	}

}
