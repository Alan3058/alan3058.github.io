package com.test.designermodel.observermodel;

public interface Listener {

	void update(int count);
}
