package com.test.designermodel.proxymodel;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class DynamicProxyRole implements InvocationHandler  {
	
	private RealRole realRole;
	public DynamicProxyRole(RealRole realRole) {
		this.realRole = realRole;
	}

	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		method.invoke(realRole, args);
		log();
		return null;
	}
	private void log(){
		System.out.println("----处理完后，记录日志----");
	}

}
