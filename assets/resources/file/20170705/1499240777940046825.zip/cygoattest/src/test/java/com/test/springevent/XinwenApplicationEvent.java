package com.test.springevent;

import org.springframework.context.ApplicationEvent;

public class XinwenApplicationEvent extends ApplicationEvent {

	public XinwenApplicationEvent(Object source) {
		super(source);
	}

}
