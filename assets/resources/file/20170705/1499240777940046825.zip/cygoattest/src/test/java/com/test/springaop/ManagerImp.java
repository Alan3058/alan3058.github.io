package com.test.springaop;

public class ManagerImp implements Manager {
	
	public void insert(String sql){
		System.out.println("--------执行插入语句"+sql+"----------");
	}

	public void find(String sql) {
		System.out.println("--------执行查询语句"+sql+"----------");
	}

	public void findAll() {
		System.out.println("--------查询所有记录----------");
	}

}
