package com.test.designermodel.templatemodel.callback;

public class SupportClass {

	public void process(CallBack callBack){
		System.out.println("通用方法实现开始");
		callBack.excute();
		System.out.println("通用方法实现结束");
	}
}
