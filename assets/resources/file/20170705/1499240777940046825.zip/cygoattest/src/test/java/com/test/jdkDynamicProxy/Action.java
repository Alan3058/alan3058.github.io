package com.test.jdkDynamicProxy;

public interface Action {

	void action();
}
