package com.test.designermodel.observermodel;

import java.util.ArrayList;
import java.util.List;

public class ConcreteSubject implements Subject {

	private List<Listener> listeners = new ArrayList<Listener>();
	private int count;
	
	public void addListener(Listener l) {
		listeners.add(l);
	}

	public void execute() {
		count++;
		System.out.println("----------业务处理完成-------");
		notifyListeners();
	}

	public void removeAllListener() {
		if(listeners!=null){
			listeners.clear();
		}
	}

	public void removeListener(Listener l) {
		if(listeners!=null){
			listeners.remove(l);
		}
	}
	
	private void notifyListeners(){
		for (Listener l : listeners) {
			System.out.println("-----监听器开始处理------");
			l.update(count);
		}
	}
}
