package com.test.springevent;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class JunitTest {

	/**
	 * 测试spring事件
	 */
	@Test
	public void testSpringEvent(){
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("bean.xml"); 
		Xinwen xinwen = (Xinwen) applicationContext.getBean("xinwen");
		xinwen.process();
	}
	
}
