package com.test.aop;

public class Check {

	public void hasPermission(){
		System.out.println("-----------校验是否有权限操作--------");
	}
}
