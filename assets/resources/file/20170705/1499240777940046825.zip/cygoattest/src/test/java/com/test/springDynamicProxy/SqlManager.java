package com.test.springDynamicProxy;

public interface SqlManager {

	public abstract void insert(String sql);

}