package com.test.designermodel.adaptermodel;

/**
 * 对象适配器模式
 * @author Alan
 *
 */
public class AdapterObject implements Target {

	private Adaptee adaptee;
	public AdapterObject(Adaptee adaptee){
		this.adaptee=adaptee;
	}
	
	public void process() {
		System.out.println("对象适配器开始适配");
		adaptee.execute();
	}

}
