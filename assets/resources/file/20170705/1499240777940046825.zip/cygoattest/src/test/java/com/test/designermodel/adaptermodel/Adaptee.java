package com.test.designermodel.adaptermodel;

public class Adaptee {

	public void execute(){
		System.out.println("----执行处理----");
	}
}
