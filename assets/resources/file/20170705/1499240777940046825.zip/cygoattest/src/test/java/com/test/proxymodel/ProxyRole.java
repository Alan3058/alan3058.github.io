package com.test.proxymodel;

public class ProxyRole implements AbstractRole {
	
	private RealRole realRole;
	public ProxyRole(){
		this.realRole=new RealRole();
	}

	public void process() {
		realRole.process();
		log();
	}
	
	private void log(){
		System.out.println("----处理完后，记录日志----");
	}

}
