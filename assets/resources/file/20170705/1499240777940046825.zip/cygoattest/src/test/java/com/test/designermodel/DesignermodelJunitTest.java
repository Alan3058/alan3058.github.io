package com.test.designermodel;

import java.lang.reflect.Proxy;

import org.junit.Test;

import com.test.designermodel.adaptermodel.Adaptee;
import com.test.designermodel.adaptermodel.AdapterClass;
import com.test.designermodel.adaptermodel.AdapterObject;
import com.test.designermodel.observermodel.ConcreteSubject;
import com.test.designermodel.observermodel.Listener;
import com.test.designermodel.observermodel.Subject;
import com.test.designermodel.proxymodel.AbstractRole;
import com.test.designermodel.proxymodel.DynamicProxyRole;
import com.test.designermodel.proxymodel.ProxyRole;
import com.test.designermodel.proxymodel.RealRole;
import com.test.designermodel.singletonmodel.Singleton;
import com.test.designermodel.templatemodel.ConcreteClass;
import com.test.designermodel.templatemodel.callback.CallBack;
import com.test.designermodel.templatemodel.callback.SupportClass;

public class DesignermodelJunitTest {

	/**
	 * 代理模式
	 */
//	@Test
	public void testProxyModel(){
		AbstractRole process = new ProxyRole();
		process.process();
	}
	/**
	 * Java动态代理模式
	 */
//	@Test
	public void testDynamicProxyModel(){
		AbstractRole process = (AbstractRole) Proxy.newProxyInstance(RealRole.class.getClassLoader(), RealRole.class.getInterfaces(), new DynamicProxyRole(new RealRole()));
		process.process();
	}
	/**
	 * Java单例模式
	 */
//	@Test
	public void testSingletonModel(){
		Singleton singleton = Singleton.getInstace();
		Singleton singleton2 = Singleton.getInstace();
		System.out.println(singleton);
		System.out.println(singleton2);
	}
	/**
	 * Java模版模式
	 */
//	@Test
	public void testTemplateModel(){
		ConcreteClass concreteClass = new ConcreteClass();
		concreteClass.process();
	}
	/**
	 * Java模版模式和回调模式
	 */
//	@Test
	public void testTemplateModelAndCallback(){
		new SupportClass().process(new CallBack() {
			
			public void excute() {
				System.out.println("---------回调执行处理---------");
			}
		});
	}
	/**
	 * 适配器模式
	 */
//	@Test
	public void testAdapterModel(){
		//类适配器模式
		new AdapterClass().process();
		//对象适配器模式
		new AdapterObject(new Adaptee()).process();
	}
	/**
	 * 观察者模式
	 */
	@Test
	public void testObserverModel(){
		Subject subject = new ConcreteSubject();
		subject.addListener(new Listener() {
			
			public void update(int count) {
				System.out.println("主题角色计数为"+count+"，监听器处理");
			}
		});
		subject.execute();
		subject.execute();
	}
}
