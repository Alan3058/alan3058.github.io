package com.test.aware;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class JunitTest {

	
	/**
	 * 测试Aware感知特性
	 */
	@Test
	public void testAware(){
		ApplicationContext ctx = new FileSystemXmlApplicationContext("H:\\workspaceST\\cygoattest\\src\\test\\resources\\bean.xml");
		ApplicationUtil util = (ApplicationUtil) ctx.getBean("applicationUtil",ApplicationUtil.class);
		System.out.println(util.getApplicationContext());
		System.out.println(util.getBeanName());
	}

}
