package com.test.springevent;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class User2 implements ApplicationListener<ApplicationEvent> {

	public void onApplicationEvent(ApplicationEvent event) {
		if(event instanceof XinwenApplicationEvent){
			System.out.println(Thread.currentThread());
			System.out.println("用户2查看新闻");
			System.out.println(event.getSource());
		}
	}

}
