package com.test.designermodel.adaptermodel;

/**
 * 类适配器模式
 * @author Alan
 *
 */
public class AdapterClass extends Adaptee implements Target {

	public void process() {
		System.out.println("类适配器开始适配");
		this.execute();
	}

}
