package com.test.proxymodel;

public interface AbstractRole {

	public void process();
}
