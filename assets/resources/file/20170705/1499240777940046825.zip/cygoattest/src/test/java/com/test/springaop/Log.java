package com.test.springaop;


public class Log {

	public void writelog(){
		System.out.println("-----------记录日志--------");
	}
}
