package com.test.springDynamicProxy;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class JunitTest {

	/**
	 * 测试Spring动态代理
	 */
	@Test
	public void testProxyFactoryBean(){
		ApplicationContext bf = new FileSystemXmlApplicationContext("H:\\workspaceST\\cygoattest\\src\\test\\resources\\bean.xml");
		SqlManager manager = (SqlManager) bf.getBean("factoryBean");
		manager.insert("");
	}

}
