package com.test.beanTest;

import org.junit.Test;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class JunitTest {

	
	/**
	 * 测试BeanFactory
	 */
	@Test
	public void testBeanFactory(){
		ClassPathResource resource = new ClassPathResource("bean.xml");
		DefaultListableBeanFactory bf = new DefaultListableBeanFactory();
		XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(bf);
		reader.loadBeanDefinitions(resource);
		Person p = bf.getBean("person", Person.class);
		p.info();
	}
	/**
	 * 测试ApplicationContext
	 */
	@Test
	public void testApplicationContext(){
		ApplicationContext ctx = new FileSystemXmlApplicationContext("H:\\workspaceST\\cygoattest\\src\\test\\resources\\bean.xml");
		Person p = (Person) ctx.getBean("person");
		p.info();
	}

}
