package com.test.designermodel.adaptermodel;

public interface Target {
	
	void process();

}
