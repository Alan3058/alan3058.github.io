package com.test.designermodel.templatemodel;

public abstract class SuperClass {

	public void process(){
		System.out.println("通用方法实现开始");
		excute();
		System.out.println("通用方法实现结束");
	}
	
	protected abstract void excute();
}
