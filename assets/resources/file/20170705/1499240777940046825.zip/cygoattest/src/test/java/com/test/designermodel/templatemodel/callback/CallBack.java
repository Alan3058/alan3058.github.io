package com.test.designermodel.templatemodel.callback;

public interface CallBack {

	public void excute();
}
