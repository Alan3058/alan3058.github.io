package com.test.springDynamicProxy;

public class SqlManagerImp implements SqlManager {
	
	public void insert(String sql){
		System.out.println("--------执行插入！----------");
	}

}
