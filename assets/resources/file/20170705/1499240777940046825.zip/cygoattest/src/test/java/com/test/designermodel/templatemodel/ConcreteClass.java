package com.test.designermodel.templatemodel;

public class ConcreteClass extends SuperClass {

	@Override
	protected void excute() {
		System.out.println("---执行处理---");
	}

}
