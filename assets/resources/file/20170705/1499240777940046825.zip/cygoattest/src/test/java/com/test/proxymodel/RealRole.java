package com.test.proxymodel;

public class RealRole implements AbstractRole {

	public void process() {
		System.out.println("--处理，操作--");
	}

}
