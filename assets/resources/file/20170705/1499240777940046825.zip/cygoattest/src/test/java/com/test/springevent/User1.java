package com.test.springevent;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public class User1 implements ApplicationListener<ApplicationEvent> {

	public void onApplicationEvent(ApplicationEvent event) {
		if(event instanceof XinwenApplicationEvent){
			System.out.println(Thread.currentThread());
			System.out.println("用户1查看新闻");
			System.out.println(event.getSource());
		}
	}

}
