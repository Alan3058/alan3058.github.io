package com.test.aop;


public class Log {

	public void writelog(){
		System.out.println("-----------输入日志--------");
	}
}
