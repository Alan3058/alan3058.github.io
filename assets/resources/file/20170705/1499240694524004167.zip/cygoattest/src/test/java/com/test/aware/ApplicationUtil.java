package com.test.aware;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class ApplicationUtil implements ApplicationContextAware,BeanNameAware {
	private ApplicationContext applicationContext;
	private String beanName;

	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext = applicationContext;
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	public void setBeanName(String name) {
		this.beanName=name;
	}

	public String getBeanName() {
		return beanName;
	}

}
