package com.test.aop;

public interface Manager {

	public abstract void insert(String sql);

}