package com.test.aop;

public class ManagerImp implements Manager {
	
	/* (non-Javadoc)
	 * @see com.test.aop.IManager#insert(java.lang.String)
	 */
	public void insert(String sql){
		System.out.println("--------执行插入！----------");
	}

}
