package com.test;

import java.lang.reflect.Proxy;

import org.junit.Test;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.test.bean.ApplicationUtil;
import com.test.bean.Person;
import com.test.jdkproxy.Action;
import com.test.jdkproxy.ActionImp;
import com.test.jdkproxy.HandlerImp;
import com.test.proxy.SqlManager;

public class JunitTest {

	
	/**
	 * 测试BeanFactory
	 */
	@Test
	public void testBeanFactory(){
		ClassPathResource resource = new ClassPathResource("bean.xml");
		DefaultListableBeanFactory bf = new DefaultListableBeanFactory();
		XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(bf);
		reader.loadBeanDefinitions(resource);
		Person p = bf.getBean("person", Person.class);
		p.info();
	}
	/**
	 * 测试ApplicationContext
	 */
//	@Test
	public void testApplicationContext(){
		ApplicationContext ctx = new FileSystemXmlApplicationContext("H:\\workspaceST\\cygoattest\\src\\test\\resources\\bean.xml");
		Person p = (Person) ctx.getBean("person");
		p.info();
	}
	/**
	 * 测试jdk动态代理
	 */
//	@Test
	public void testJdkProxy(){
		Action obj = (Action) Proxy.newProxyInstance(ActionImp.class.getClassLoader(), ActionImp.class.getInterfaces(), new HandlerImp(new ActionImp()));
		obj.action();
	}
	/**
	 * 测试Spring动态代理
	 */
//	@Test
	public void testProxyFactoryBean(){
		ApplicationContext bf = new FileSystemXmlApplicationContext("H:\\workspaceST\\cygoattest\\src\\test\\resources\\bean.xml");
		SqlManager manager = (SqlManager) bf.getBean("factoryBean");
		manager.insert("");
	}
	/**
	 * 测试Aware感知特性
	 */
//	@Test
	public void testAware(){
		ApplicationContext ctx = new FileSystemXmlApplicationContext("H:\\workspaceST\\cygoattest\\src\\test\\resources\\bean.xml");
		ApplicationUtil util = (ApplicationUtil) ctx.getBean("applicationUtil",ApplicationUtil.class);
		System.out.println(util.getApplicationContext());
		System.out.println(util.getBeanName());
	}
	
	

	
}
