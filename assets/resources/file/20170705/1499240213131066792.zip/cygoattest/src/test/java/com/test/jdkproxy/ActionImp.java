package com.test.jdkproxy;

public class ActionImp implements Action {

	public void action() {
		// TODO Auto-generated method stub
		System.out.println("-------执行操作--------");
	}

}
