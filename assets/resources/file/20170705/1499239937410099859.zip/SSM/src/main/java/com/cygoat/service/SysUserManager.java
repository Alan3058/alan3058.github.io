package com.cygoat.service;

import com.cygoat.model.SysUser;

public interface SysUserManager {

	public SysUser get(String id);

}