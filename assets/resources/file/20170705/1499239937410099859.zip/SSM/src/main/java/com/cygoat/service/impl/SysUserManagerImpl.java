package com.cygoat.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cygoat.dao.SysUserMapper;
import com.cygoat.model.SysUser;
import com.cygoat.service.SysUserManager;

@Service
public class SysUserManagerImpl implements SysUserManager {
	@Autowired
	private SysUserMapper sysUserMapper;

	public SysUser get(String id){
		return sysUserMapper.selectByPrimaryKey(id);
	}
}
