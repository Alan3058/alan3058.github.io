package com.cygoat.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cygoat.service.SysUserManager;

@Controller
@RequestMapping("sysUser")
public class SysUserController {

	@Autowired
	private SysUserManager sysUserManager;
	
	@RequestMapping("get")
	@ResponseBody
	public Object get(String id){
		return sysUserManager.get(id);
	}
}
