package com.cygoat.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cygoat.service.SysUserManager;

public class SysUserManagerImplTest {
	
	private ApplicationContext ac;

	@Before
	public void setUp() throws Exception {
		ac = new ClassPathXmlApplicationContext("spring.xml");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGet() {
		SysUserManager obj = (SysUserManager)ac.getBean("sysUserManagerImpl");
		assertNotNull("not null", obj.get("1"));
	}

}
