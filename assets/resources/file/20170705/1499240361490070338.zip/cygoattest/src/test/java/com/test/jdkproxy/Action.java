package com.test.jdkproxy;

public interface Action {

	void action();
}
