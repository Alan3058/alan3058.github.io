package com.test.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
@Component
public class ApplicationUtil implements ApplicationContextAware,BeanNameAware {
	private ApplicationContext applicationContext;
	private String beanName;

	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		// TODO Auto-generated method stub
		this.applicationContext = applicationContext;
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	public void setBeanName(String name) {
		// TODO Auto-generated method stub
		this.beanName=name;
	}

	public String getBeanName() {
		return beanName;
	}

}
