package com.test.proxy;

public interface SqlManager {

	public abstract void insert(String sql);

}